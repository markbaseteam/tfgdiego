---

kanban-plugin: basic
dg-home: true
dg-publish: true

---

## Backlog

- [ ] Generar una presentación con imágenes #Prot2
- [ ] [[03 - Resumir PDF]] #Prot2
- [ ] XX - Internacionalización a Inglés


## TODO

- [ ] Incorporar API de Google Docs #Prot1
- [ ] Visualizar vista previa del documento analizado #Prot1 ^k3kwt0
- [ ] 07 - Permitir al usuario informar de si el título y subtítulos extraídos son correctos. #Prot1


## In Progress

- [ ] [[05 - Analizar PDF]] #Prot1
- [ ] [[05.1 - Pantalla  Cargando]] #Prot1
- [ ] [[05.2 - Ignorar texto irrelevante]] #Prot1


## Done

**Complete**
- [x] [[001 - Investigar sobre los ADR de GitHub ⏫]] #Plan
- [x] Interfaz de Usuario @{2022-12-28} #Plan ^p9hfat
- [x] Elegir un Framework @{2022-12-31} #Plan ^g2ultw
- [x] [[04 - Subir PDF para resumirlo]] @{2023-01-03} #Prot1
- [x] [[02_Extraer datos del PDF]] #Prot1 @{2023-01-26}
- [x] Página de inicio ✅ 2022-12-31 #Prot1 ^gl8enm


## Archive





%% kanban:settings
```
{"kanban-plugin":"basic","new-note-folder":"TFG/Diario","show-archive-all":true,"tag-colors":[{"tagKey":"#Prot1","color":"","backgroundColor":"rgba(229, 110, 66, 0.67)"}],"show-checkboxes":true,"hide-tags-display":false,"hide-tags-in-title":true,"hide-date-in-title":true}
```
%%