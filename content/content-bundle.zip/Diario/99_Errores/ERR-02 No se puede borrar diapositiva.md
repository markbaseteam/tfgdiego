```python
def delete_slide(self, presentation_id, slide_id):  
    """Delete a slide with the given ID."""  
    try:  
        self.service.presentations().batchDelete(  
            presentationId=presentation_id,  
            body={  
                'requests': [{  
                    'deleteObject': {  
                        'objectId': slide_id  
                    }  
                }]  
            }).execute()  
        Logger.debug('Deleted slide with ID: {0}'.format(slide_id))  
    except HttpError as e:  
        Logger.error('An error occurred: {0}'.format(e))
```

Ni idea de cómo borrar una diapositiva, tiene pinta de que no se puede así que me voy a tener que conformar con editar la primera diapositiva de cualquier forma.