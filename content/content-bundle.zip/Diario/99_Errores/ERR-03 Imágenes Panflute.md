No hay manera de que panflute pille las imágenes del archivo markdown así que va a haber que pillarlas a lo cutre tiene toda la pinta.

# Intentos
## Cambiar el path de pandoc.
Puede ser que las imágenes no las esté pillando porque no es capaz de sacar el path relativo dado que se ejecuta la aplicación en un lugar diferente al markdown.

```python
def init_content(self):  
    # Open the markdown file  
    with open(self.path, 'r', encoding='utf-8') as f:  
        doc = panflute.convert_text(f.read(), input_format='markdown', pandoc_path  ="sessions/" + self.current_session + "/")  
    images = []  
    paras = {}  
    Logger.debug('Markdown: Getting titles and paragraphs')  
    for elem in doc.content:  
        if isinstance(elem, panflute.Header) and elem.level == 1:  
            self.title = parse_text(elem)  
            last_header = elem  
        elif isinstance(elem, panflute.Header):  
            last_header = elem  
        elif isinstance(elem, panflute.Para):  
            paras[last_header] = paras.get(last_header, []) + [elem]  
        elif isinstance(elem, panflute.Image):  
            images.append(elem)  
    self.paras = paras  
    self.images = images
```

Ni siquiera sale la opción de pandoc_path, pero quizá intentando el workaround típico de cambiar manualmente... 

```python
with open(self.path, 'r', encoding='utf-8') as f:  
    curr_dir  = os.getcwd()  
    os.chdir(os.path.dirname("sessions/" + self.current_session + "/"))  
    doc = panflute.convert_text(f.read(), input_format='markdown')  
    os.chdir(curr_dir)
```

Sigue sin sacar las imágenes, así que habrá que hacerlo bien cutre.

He visto que está bastante pegado el texto del archivo .md y esto con los títulos daba problemas. Probablemente también ocurra el mismo problema con las imágenes, así que quizá separándolo un poco mejora la situación.

# ✔