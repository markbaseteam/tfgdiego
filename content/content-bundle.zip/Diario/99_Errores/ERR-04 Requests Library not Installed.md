Se refiere a que el paquete "requests" de google no está instalado, cosa que no tiene sentido porque sí que lo está. Puede perfectamente ser un tema de incompatibilidades con alguna otra dependencia así que quizá lo mejor es crear un enviroment nuevo desde cero.

