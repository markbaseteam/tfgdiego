
> [!error] module 'ntpath' has no attribute 'sep'
> Ocurre este error intentando descargar el modelo, también ocurre intentando descargar imágenes. Toca solucionarlo a full.

#### Solucionar el error.
Tras mucho intento y error, he cambiado de python a usar Anaconda. He instalado mil veces el tema este y ahora acabo de probar a intalar el paquete transformers con conda.

```shell
conda install -c huggingface transformers
```

Qué va, tampoco funciona... El problema reside en este fragmento de código:

```python
folder = os.path.sep.join(resolved_archive_file[0].split(os.path.sep)[:-1])
```

> [!success] Se soluciona cambiando a la versión 3.8 de python
> 