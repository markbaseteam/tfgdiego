# El tema de Auron y Biyín

## Introducción

Este fin de semana ha sido bastante movidito para los creadores de contenido españoles. Después de saltar la **polémica sobre el pasado de Biyin, Auronplay** y unos cuantos tuiteros más, muchos se han tirado al cuello (y con razón) de estos _streamers._

## Contenido

Después de dar sus versiones en [Twitch](https://www.3djuegos.com/tag/twitch), **Auron** ha comentado a través de un directo desde su canal que **se tomará unos días de descanso** para volver con más fuerza. El propio [_streamer_](https://www.3djuegos.com/tag/streamers) ni siquiera sabe cuando volverá, pero ha asegurado a sus seguidores que no se retira del todo.

Si bien parece que está harto de _stremear_ y ha reiterado varias veces que no le queda mucho como esta faceta_,_ todo apunta a que desaparecerá de toda red social hasta que la tormenta de sus actitudes en 2013 desaparezcan poco a poco y vuelvan a hacer directos como si nada de esto hubiera pasado. 

Esta técnica no es nueva, ya que hemos visto una buena cantidad de creadores de contenido que han hecho la misma técnica a pesar de las malas decisiones que hayan tomado y que han vuelto como si nada. No sabremos si ocurrirá lo mismo, pero si hay algo seguro es que esta polémica será bastante recordada por todos.