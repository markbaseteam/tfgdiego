# Subir fichero en markown
Hoy toca hacer las cosas como se debía de hacer y no como a mçi me dio la gana jajajajajaj.

# Qué resumo exactamente.
Cómo dividir el tema del resumen de momento. Lo más lógico parece ser hacerlo a través de número de palabras más que por párrafos si los párrafos no son lo suficientemente largos. Lo suyo sería intentar encontrar el párrafo más largo y realizar el resumen agrupando según el mismo. Asumiendo que el párrafo más largo es en el que se ha tratado la información de forma más detallada y probablemente significa que esa información debe de resumirse por separado.

Para ello primero vamos a calcular el párrafo de mayor tamaño. Aquel párrafo con mayor número de palabras será la referencia en cuanto a si debemos agrupar algunos de los párrafos o no. **Si un párrafo es menor que la mitad del párrafo** con más palabras se intentará agrupar con el siguiente. (A no ser que el siguiente sea el párrafo con más palabras).
