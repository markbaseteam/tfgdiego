# Grupos de Osos Polares Migran al norte de Canadá donde el hielo aguanta más tiempo.

## Introducción
JUNEAU (Reuters) - Algunos grupos de osos polares se han desplazado lentamente hasta las islas del norte del área continental de Canadá que retienen el hielo del Ártico durante más tiempo, según un nuevo estudio científico que predice que esta migración, relacionada con el cambio climático, podría continuar.

## Contenido
El informe, publicado a comienzos de este mes en la revista “PLOS ONE” se basa en los datos de ADN tomados de cerca de 2.800 osos polares de los países donde habitan: Estados Unidos, Rusia, Canadá, Groenlandia y Noruega.

Los investigadores han rastreado el cambio a través de las similitudes genéticas de osos de cuatro regiones.

Grupos de osos de la zona ártica del este de Canadá y del área marina del este de Groenlandia y Siberia se están trasladando al archipiélago canadiense, más conocido como el Archipiélago Ártico, donde el hielo es más abundante, según el estudio.

Los canales a través de las islas, conocidos como el paso del Noroeste, ha llegado a verse como una ruta potencialmente valiosa de traslado, mientras el hielo se derrite en el Ártico.

La región que ha atraído a un gran número de osos polares se sitúa al norte de la zona continental canadiense, cerca de Nunavut y de los Territorios del Noroeste. Se compone de más de 36.000 islas y cubre más de 1,4 millones de kilómetros cuadrados.

Las migraciones han tenido lugar entre una y tres generaciones de predadores, o entre 15 y 45 años, dijo en un comunicado Elizabeth Peacock, autora del informe e investigadora del Servicio Geológico de Estados Unidos.

Los osos escogen esta zona porque es “donde el mar es más resistente a los derretimientos de verano debido a los patrones de circulación, a la compleja geografía y a la latitud, más al norte, por lo que es más fría”, dijo Peacock.

El Archipiélago Canadiense podría servir como futuro refugio para los osos polares, que confían en el hielo ártico para cruzar entre las masas de tierra, para alimentarse y aparearse, según los investigadores.

Desde 1979, la extensión espacial del hielo ártico en otoño se ha reducido más de un 9 por ciento por década hasta 2010, dijeron los investigadores, añadiendo que los recientes diseños predicen que los veranos casi sin hielos caracterizarán el Ártico antes de mediados de siglo.