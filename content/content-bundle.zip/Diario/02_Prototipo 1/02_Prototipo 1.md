# Objetivos
- Poder generar una presentación en Google Slides a partir de un documento pdf.
- La presentación debe contener texto extraído y resumido del pdf
- La aplicación debe poder ejecutarse en windows sin problema

# Diarios de las tareas

%% Begin Waypoint %%
- [[01_Botón de Inicio]]
- [[02_Extraer datos del PDF]]
- [[02_Prototipo 1]]
- [[03 - Resumir PDF]]
- [[04 - Subir PDF para resumirlo]]
- [[05 - Analizar PDF]]
- [[05.1 - Pantalla  Cargando]]
- [[05.2 - Ignorar texto irrelevante]]
- **assets**


%% End Waypoint %%
