# Mejoras

- [ ] BASE_DIR a la hora de cambiar de dispositivo (En PC2 hay un ejemplo)
- [ ] Nested titles, para cuando un título t2 