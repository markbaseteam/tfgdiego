# CodePatterns

# Strategy
Para que una misma cosa cambie la estrategia con la que realiza el tema. Por ejemplo para cambiar el sentido del que se lee una lista.

```embed
title: 'Strategy in Python / Design Patterns'
image: 'https://refactoring.guru/images/refactoring/social/facebook-share-preview.png?id=dbf9e98269595be86eb668f365be6868'
description: 'Strategy pattern in Python. Full code example in Python with detailed comments and explanation. Strategy is a behavioral design pattern that turns a set of behaviors into objects and makes them interchangeable inside original context object.'
url: 'https://refactoring.guru/design-patterns/strategy/python/example#lang-features'
```

# Visitors
Una clase que va mirando a otra y decide qué hacer en el caso que convenga según un atributo o algo.

```embed
title: 'Visitor'
image: 'https://refactoring.guru/images/refactoring/social/facebook-share-preview.png?id=dbf9e98269595be86eb668f365be6868'
description: 'Visitor is a behavioral design pattern that lets you separate algorithms from the objects on which they operate.'
url: 'https://refactoring.guru/design-patterns/visitor'
```
