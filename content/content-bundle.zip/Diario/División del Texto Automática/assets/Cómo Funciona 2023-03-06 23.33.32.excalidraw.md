---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
The wolf let out a satisfied burp, and then poked through Granny's 
wardrobe to find a nightgown that he liked.  He added a frilly sleeping 
cap, and for good measure, dabbed some of Granny's perfume behind 
his pointy ears.

A few minutes later, Red Riding Hood knocked on the door.  
The wolf jumped into bed and pulled the covers over his nose.  
"Who is it?" he called in a cackly voice. ^gCFSMRRC

1. ^a0gKlYTJ

The wolf let out a satisfied burp, and then poked through Granny's 
wardrobe to find a nightgown that he liked.  He added a frilly sleeping 
cap, and for good measure, dabbed some of Granny's perfume behind 
his pointy ears.

A few minutes later, Red Riding Hood knocked on the door.  
The wolf jumped into bed and pulled the covers over his nose.  
"Who is it?" he called in a cackly voice. ^S7mjIs9e

2. ^rad9fkSj

3. ^FI1fn7nI

- The wolf let out a satisfied burp, and then poked through Granny's 
    wardrobe to find a nightgown that he liked.  

- He added a frilly sleeping cap, and for good measure, dabbed some of 
    Granny's perfume behind his pointy ears.

- A few minutes later, Red Riding Hood knocked on the door.  

- The wolf jumped into bed and pulled the covers over his nose.  
    "Who is it?" he called in a cackly voice. ^NW1ptYU6

Compara la similitud de cada una de 
las frases con la primera ^vQvCf7Qi

4. ^1sleZsiw

- The wolf let out a satisfied burp, and then poked through Granny's 
    wardrobe to find a nightgown that he liked.  

- He added a frilly sleeping cap, and for good measure, dabbed some of 
    Granny's perfume behind his pointy ears.

- A few minutes later, Red Riding Hood knocked on the door.  

- The wolf jumped into bed and pulled the covers over his nose.  
    "Who is it?" he called in a cackly voice. ^amwwD9MJ

0.6 ^P2K4mmgq

0.1 ^fZ9Ff9k6

0.5 ^5OZeMdAo

Si el umbral elegido es inferior al valor de 
similitud ([-1, 1]), se añade esa frase al 
texto primero. ^EWesDoey

Suponiendo que la tercera frase 
no supera el umbral seleccionado ^HDzUhEx7


- A few minutes later, Red Riding Hood knocked on the door.  

- The wolf jumped into bed and pulled the covers over his nose.  
    "Who is it?" he called in a cackly voice. ^8Dt5JY00

5. ^VNhkOVpG

Se repite el proceso desde el punto 1 ^tHazFFH5

- The wolf let out a satisfied burp, and then poked through Granny's 
    wardrobe to find a nightgown that he liked.  

- He added a frilly sleeping cap, and for good measure, dabbed some of 
    Granny's perfume behind his pointy ears. ^Kc72aT7m

Se Resume el texto y se genera una diapositiva ^pm7j0DTi

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"id": "gCFSMRRC",
			"type": "text",
			"x": -445.75,
			"y": -233,
			"width": 706,
			"height": 200,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 741584733,
			"version": 38,
			"versionNonce": 1201722621,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "cGUb_ZeaZOMyb4Cx2GNYO",
					"type": "arrow"
				},
				{
					"id": "_eqmu-RPHkKqa_5czon7f",
					"type": "arrow"
				}
			],
			"updated": 1678142954782,
			"link": null,
			"locked": false,
			"text": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice.",
			"rawText": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice.",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 193,
			"containerId": null,
			"originalText": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice."
		},
		{
			"id": "a0gKlYTJ",
			"type": "text",
			"x": -452.8219328707485,
			"y": -344.43689166224897,
			"width": 34,
			"height": 77,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 484825683,
			"version": 178,
			"versionNonce": 1555962547,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142388250,
			"link": null,
			"locked": false,
			"text": "1.",
			"rawText": "1.",
			"fontSize": 60.83715098663494,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 54,
			"containerId": null,
			"originalText": "1."
		},
		{
			"type": "text",
			"version": 150,
			"versionNonce": 1073469565,
			"isDeleted": false,
			"id": "S7mjIs9e",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -442.9590741755229,
			"y": 165.59962281680833,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 706,
			"height": 200,
			"seed": 336952723,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "DeFMrJEOonrqB-oTQLyab",
					"type": "arrow"
				},
				{
					"id": "cGUb_ZeaZOMyb4Cx2GNYO",
					"type": "arrow"
				}
			],
			"updated": 1678142932496,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice.",
			"rawText": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice.",
			"baseline": 193,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "The wolf let out a satisfied burp, and then poked through Granny's \nwardrobe to find a nightgown that he liked.  He added a frilly sleeping \ncap, and for good measure, dabbed some of Granny's perfume behind \nhis pointy ears.\n\nA few minutes later, Red Riding Hood knocked on the door.  \nThe wolf jumped into bed and pulled the covers over his nose.  \n\"Who is it?\" he called in a cackly voice."
		},
		{
			"type": "text",
			"version": 294,
			"versionNonce": 211720595,
			"isDeleted": false,
			"id": "rad9fkSj",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -450.0310070462714,
			"y": 52.33909843169471,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 61,
			"height": 77,
			"seed": 3741981,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1678142380321,
			"link": null,
			"locked": false,
			"fontSize": 60.83715098663494,
			"fontFamily": 1,
			"text": "2.",
			"rawText": "2.",
			"baseline": 54,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "2."
		},
		{
			"id": "MbS_i9112qaaV5FyE4lkQ",
			"type": "line",
			"x": -18.662385040031097,
			"y": 212.08545079874534,
			"width": 428.7311352497095,
			"height": 4.554048477614515,
			"angle": 0,
			"strokeColor": "#c92a2a",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 721348541,
			"version": 115,
			"versionNonce": 796405021,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142237817,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-428.7311352497095,
					4.554048477614515
				]
			],
			"lastCommittedPoint": [
				-428.7311352497095,
				4.554048477614515
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "J3WsppjLsX2jDixXDR7be",
			"type": "line",
			"x": 241.238410433353,
			"y": 185.56820465847397,
			"width": 685.1772282421653,
			"height": 3.844990057475684,
			"angle": 0,
			"strokeColor": "#c92a2a",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1983918099,
			"version": 107,
			"versionNonce": 1988882995,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142267785,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-685.1772282421653,
					3.844990057475684
				]
			],
			"lastCommittedPoint": [
				-685.1772282421653,
				3.844990057475684
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "5Jm8owOPOZRo0PRwr-eFW",
			"type": "line",
			"x": 1.311030846870949,
			"y": 211.7141370493086,
			"width": 256.845335839375,
			"height": 1.537996022990285,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 257242067,
			"version": 58,
			"versionNonce": 331696477,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142276991,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					256.845335839375,
					-1.537996022990285
				]
			],
			"lastCommittedPoint": [
				256.845335839375,
				-1.537996022990285
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "yiUmIJPX-BwP2qXflLuC3",
			"type": "line",
			"x": -443.16981979731713,
			"y": 236.32207341715292,
			"width": 680.5632401731945,
			"height": 3.844990057475684,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1382946237,
			"version": 71,
			"versionNonce": 1140817629,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142283292,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					680.5632401731945,
					3.844990057475684
				]
			],
			"lastCommittedPoint": [
				680.5632401731945,
				3.844990057475684
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "KE0mbr-YrjzkWq3acUE9x",
			"type": "line",
			"x": -441.6318237743269,
			"y": 265.54399785396805,
			"width": 145.34062417258053,
			"height": 0,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 484583795,
			"version": 53,
			"versionNonce": 1927364531,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142293454,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					145.34062417258053,
					0
				]
			],
			"lastCommittedPoint": [
				145.34062417258053,
				0
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "RgHXGraTEv-i86hPOQOQd",
			"type": "line",
			"x": -442.400821785822,
			"y": 312.4528765551713,
			"width": 576.7485086213513,
			"height": 0,
			"angle": 0,
			"strokeColor": "#e67700",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1050988883,
			"version": 74,
			"versionNonce": 1687688925,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142302505,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					576.7485086213513,
					0
				]
			],
			"lastCommittedPoint": [
				576.7485086213513,
				0
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "3aM0NYcRcWoalpr15XAdz",
			"type": "line",
			"x": -440.09382775133656,
			"y": 337.06081292301565,
			"width": 612.1224171501275,
			"height": 2.306994034485342,
			"angle": 0,
			"strokeColor": "#0b7285",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1787507517,
			"version": 112,
			"versionNonce": 1753603187,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142315413,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					612.1224171501275,
					2.306994034485342
				]
			],
			"lastCommittedPoint": [
				612.1224171501275,
				2.306994034485342
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "EX0GbCG9ajhRDPkC6kKMe",
			"type": "line",
			"x": -450.09080190077333,
			"y": 364.74474133684043,
			"width": 404.492954046441,
			"height": 0,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1998050835,
			"version": 53,
			"versionNonce": 1207380669,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142335702,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					404.492954046441,
					0
				]
			],
			"lastCommittedPoint": [
				404.492954046441,
				0
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "text",
			"version": 341,
			"versionNonce": 942343731,
			"isDeleted": false,
			"id": "FI1fn7nI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -447.11120664936914,
			"y": 443.8770907871636,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 59,
			"height": 77,
			"seed": 1947531997,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678142392920,
			"link": null,
			"locked": false,
			"fontSize": 60.83715098663494,
			"fontFamily": 1,
			"text": "3.",
			"rawText": "3.",
			"baseline": 54,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "3."
		},
		{
			"type": "text",
			"version": 261,
			"versionNonce": 459135229,
			"isDeleted": false,
			"id": "NW1ptYU6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -427.76915128843916,
			"y": 522.5593809618404,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 719,
			"height": 250,
			"seed": 1355957245,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "EqFFjzMrwawirvNkTtFjV",
					"type": "arrow"
				},
				{
					"id": "DeFMrJEOonrqB-oTQLyab",
					"type": "arrow"
				}
			],
			"updated": 1678142926752,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"rawText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"baseline": 243,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice."
		},
		{
			"id": "DzQ-x9kxczw2Ql11zxaxi",
			"type": "rectangle",
			"x": -433.67657083145707,
			"y": 519.2235686512543,
			"width": 712.2789919979689,
			"height": 60.89431796873828,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 291900861,
			"version": 99,
			"versionNonce": 1208195517,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "xGTsFdA_UNx3PqZn-XAAR",
					"type": "arrow"
				},
				{
					"id": "BRixFBBpqCMpgm6NwMPAi",
					"type": "arrow"
				}
			],
			"updated": 1678142542453,
			"link": null,
			"locked": false
		},
		{
			"id": "gQEiUtNNvUq3JBjb3YKo8",
			"type": "arrow",
			"x": 84.84777308416233,
			"y": 576.4273218946145,
			"width": 59.04903560604919,
			"height": 72.88865332621697,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2069963485,
			"version": 68,
			"versionNonce": 1545704211,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142516577,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					59.04903560604919,
					72.88865332621697
				],
				[
					3.690564725378067,
					47.9773414299151
				]
			],
			"lastCommittedPoint": [
				3.690564725378067,
				47.9773414299151
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "xGTsFdA_UNx3PqZn-XAAR",
			"type": "arrow",
			"x": 120.83077915659851,
			"y": 581.9631689826815,
			"width": 126.40184184419923,
			"height": 171.61125973008075,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 516103069,
			"version": 132,
			"versionNonce": 703992403,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142527752,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					126.40184184419923,
					171.61125973008075
				],
				[
					54.435829699326746,
					122.71127711882104
				]
			],
			"lastCommittedPoint": [
				54.435829699326746,
				122.71127711882104
			],
			"startBinding": {
				"elementId": "DzQ-x9kxczw2Ql11zxaxi",
				"focus": -0.46116854698166737,
				"gap": 1.8452823626889767
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "BRixFBBpqCMpgm6NwMPAi",
			"type": "arrow",
			"x": 161.42699113575736,
			"y": 580.1178866199925,
			"width": 226.96973061075175,
			"height": 249.11311896302027,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1702698173,
			"version": 244,
			"versionNonce": 528605779,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1678142547809,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					184.52823626890392,
					249.11311896302027
				],
				[
					-42.44149434184783,
					180.83767154352586
				]
			],
			"lastCommittedPoint": [
				-42.44149434184783,
				180.83767154352586
			],
			"startBinding": {
				"elementId": "DzQ-x9kxczw2Ql11zxaxi",
				"focus": -0.5714672441797497,
				"gap": 1
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "vQvCf7Qi",
			"type": "text",
			"x": 273.98921525978903,
			"y": 639.3933340394867,
			"width": 373,
			"height": 50,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 769764637,
			"version": 178,
			"versionNonce": 1091487645,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142572799,
			"link": null,
			"locked": false,
			"text": "Compara la similitud de cada una de \nlas frases con la primera",
			"rawText": "Compara la similitud de cada una de \nlas frases con la primera",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Compara la similitud de cada una de \nlas frases con la primera"
		},
		{
			"type": "text",
			"version": 388,
			"versionNonce": 684872435,
			"isDeleted": false,
			"id": "1sleZsiw",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -436.4228326375815,
			"y": 957.5578834065427,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57,
			"height": 77,
			"seed": 824360531,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678142586424,
			"link": null,
			"locked": false,
			"fontSize": 60.83715098663494,
			"fontFamily": 1,
			"text": "4.",
			"rawText": "4.",
			"baseline": 54,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "4."
		},
		{
			"type": "text",
			"version": 326,
			"versionNonce": 1182455411,
			"isDeleted": false,
			"id": "amwwD9MJ",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -392.2966811757243,
			"y": 1039.6781206851263,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 719,
			"height": 250,
			"seed": 1170246173,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "cpocOuzMTJcX23bK9TqQb",
					"type": "arrow"
				},
				{
					"id": "yuJB4xenphaO1FA76Zdnf",
					"type": "arrow"
				}
			],
			"updated": 1678142808187,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"rawText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"baseline": 243,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.\n\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice."
		},
		{
			"id": "p6p6esirKcz2D3CZOnu8v",
			"type": "rectangle",
			"x": 340.9759880820266,
			"y": 1109.4961231239845,
			"width": 44,
			"height": 43,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 150254301,
			"version": 114,
			"versionNonce": 154107603,
			"isDeleted": false,
			"boundElements": [
				{
					"type": "text",
					"id": "P2K4mmgq"
				}
			],
			"updated": 1678142657696,
			"link": null,
			"locked": false
		},
		{
			"id": "P2K4mmgq",
			"type": "text",
			"x": 346.4759880820266,
			"y": 1118.4961231239845,
			"width": 33,
			"height": 25,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1937262781,
			"version": 91,
			"versionNonce": 44747741,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142657696,
			"link": null,
			"locked": false,
			"text": "0.6",
			"rawText": "0.6",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"baseline": 18,
			"containerId": "p6p6esirKcz2D3CZOnu8v",
			"originalText": "0.6"
		},
		{
			"type": "rectangle",
			"version": 154,
			"versionNonce": 2065685107,
			"isDeleted": false,
			"id": "eXic88NWyGwni9Foz5Xwe",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 344.1376175310002,
			"y": 1171.9862679299933,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 39,
			"seed": 153218909,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "fZ9Ff9k6"
				}
			],
			"updated": 1678142663396,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 154,
			"versionNonce": 725056061,
			"isDeleted": false,
			"id": "fZ9Ff9k6",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 353.1376175310002,
			"y": 1178.9862679299933,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 26,
			"height": 25,
			"seed": 96272627,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678142663396,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "0.1",
			"rawText": "0.1",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "eXic88NWyGwni9Foz5Xwe",
			"originalText": "0.1"
		},
		{
			"type": "rectangle",
			"version": 194,
			"versionNonce": 983941469,
			"isDeleted": false,
			"id": "lxAkYuRTMOz35cW-JIes9",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 345.67638236091176,
			"y": 1231.5959922904003,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 44,
			"height": 35,
			"seed": 430331955,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"type": "text",
					"id": "5OZeMdAo"
				}
			],
			"updated": 1678142660779,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 203,
			"versionNonce": 2090290931,
			"isDeleted": false,
			"id": "5OZeMdAo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 351.17638236091176,
			"y": 1236.5959922904003,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 33,
			"height": 25,
			"seed": 2091956349,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678142660779,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "0.5",
			"rawText": "0.5",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "lxAkYuRTMOz35cW-JIes9",
			"originalText": "0.5"
		},
		{
			"id": "y0f-g6rzCjLyrqln5rBfL",
			"type": "rectangle",
			"x": -412.25172500299044,
			"y": 1029.5826933402705,
			"width": 750.5782977452998,
			"height": 149.26272966525858,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 3
			},
			"seed": 572992157,
			"version": 69,
			"versionNonce": 484685235,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "EqFFjzMrwawirvNkTtFjV",
					"type": "arrow"
				}
			],
			"updated": 1678142921927,
			"link": null,
			"locked": false
		},
		{
			"id": "EWesDoey",
			"type": "text",
			"x": 353.80327900245493,
			"y": 1009.3734585170278,
			"width": 427,
			"height": 75,
			"angle": 0,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 190047891,
			"version": 188,
			"versionNonce": 1783919101,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142759394,
			"link": null,
			"locked": false,
			"text": "Si el umbral elegido es inferior al valor de \nsimilitud ([-1, 1]), se añade esa frase al \ntexto primero.",
			"rawText": "Si el umbral elegido es inferior al valor de \nsimilitud ([-1, 1]), se añade esa frase al \ntexto primero.",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 68,
			"containerId": null,
			"originalText": "Si el umbral elegido es inferior al valor de \nsimilitud ([-1, 1]), se añade esa frase al \ntexto primero."
		},
		{
			"id": "cpocOuzMTJcX23bK9TqQb",
			"type": "arrow",
			"x": -53.36032810526524,
			"y": 1306.693005811494,
			"width": 498.37366835173157,
			"height": 240.18753272332265,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1316684147,
			"version": 205,
			"versionNonce": 342471261,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142987943,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					4.009553825577086,
					130.97875830218436
				],
				[
					442.38743875533623,
					126.96920447660705
				],
				[
					498.37366835173157,
					240.18753272332265
				]
			],
			"lastCommittedPoint": [
				482.48297701110687,
				236.56367570904695
			],
			"startBinding": {
				"elementId": "amwwD9MJ",
				"focus": 0.06856378291507377,
				"gap": 17.014885126367744
			},
			"endBinding": {
				"elementId": "Kc72aT7m",
				"focus": 0.07724514927031088,
				"gap": 10.988031602732008
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "yuJB4xenphaO1FA76Zdnf",
			"type": "arrow",
			"x": -49.35077427968815,
			"y": 1306.693005811494,
			"width": 465.3775340039249,
			"height": 221.86197834859786,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1993361661,
			"version": 226,
			"versionNonce": 1216016563,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1678142871643,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-2.6730358837180574,
					144.34393772077442
				],
				[
					-411.6475260925788,
					137.66134801147928
				],
				[
					-465.3775340039249,
					221.86197834859786
				]
			],
			"lastCommittedPoint": [
				-443.7239566971953,
				221.86197834859786
			],
			"startBinding": {
				"elementId": "amwwD9MJ",
				"focus": 0.038484294323251074,
				"gap": 17.014885126367744
			},
			"endBinding": {
				"elementId": "8Dt5JY00",
				"focus": -0.3122987162846907,
				"gap": 27.40929160734413
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "HDzUhEx7",
			"type": "text",
			"x": -440.49516298827757,
			"y": 1334.8416646199685,
			"width": 330,
			"height": 50,
			"angle": 0,
			"strokeColor": "#2b8a3e",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 529403155,
			"version": 216,
			"versionNonce": 1217104243,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142850776,
			"link": null,
			"locked": false,
			"text": "Suponiendo que la tercera frase \nno supera el umbral seleccionado",
			"rawText": "Suponiendo que la tercera frase \nno supera el umbral seleccionado",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"baseline": 43,
			"containerId": null,
			"originalText": "Suponiendo que la tercera frase \nno supera el umbral seleccionado"
		},
		{
			"type": "text",
			"version": 394,
			"versionNonce": 1580134557,
			"isDeleted": false,
			"id": "8Dt5JY00",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -783.4926575474924,
			"y": 1555.964275767436,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 651,
			"height": 125,
			"seed": 349293469,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "yuJB4xenphaO1FA76Zdnf",
					"type": "arrow"
				},
				{
					"id": "_eqmu-RPHkKqa_5czon7f",
					"type": "arrow"
				}
			],
			"updated": 1678142954782,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"rawText": "\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice.",
			"baseline": 118,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "\n- A few minutes later, Red Riding Hood knocked on the door.  \n\n- The wolf jumped into bed and pulled the covers over his nose.  \n    \"Who is it?\" he called in a cackly voice."
		},
		{
			"type": "text",
			"version": 426,
			"versionNonce": 2050695731,
			"isDeleted": false,
			"id": "VNhkOVpG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -742.4652531498596,
			"y": 1384.3179406580118,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 55,
			"height": 77,
			"seed": 1274800797,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678142864559,
			"link": null,
			"locked": false,
			"fontSize": 60.83715098663494,
			"fontFamily": 1,
			"text": "5.",
			"rawText": "5.",
			"baseline": 54,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "5."
		},
		{
			"type": "text",
			"version": 351,
			"versionNonce": 1401353917,
			"isDeleted": false,
			"id": "tHazFFH5",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -708.3296226440647,
			"y": 1701.9501272564326,
			"strokeColor": "#2b8a3e",
			"backgroundColor": "transparent",
			"width": 369,
			"height": 25,
			"seed": 1049354333,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678143010406,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Se repite el proceso desde el punto 1",
			"rawText": "Se repite el proceso desde el punto 1",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Se repite el proceso desde el punto 1"
		},
		{
			"id": "EqFFjzMrwawirvNkTtFjV",
			"type": "arrow",
			"x": -76.42203166721424,
			"y": 793.4675553492926,
			"width": 3.6472654457293174,
			"height": 209.71776312943882,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 565127325,
			"version": 33,
			"versionNonce": 1554117373,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142921930,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					3.6472654457293174,
					209.71776312943882
				]
			],
			"lastCommittedPoint": [
				3.6472654457293174,
				209.71776312943882
			],
			"startBinding": {
				"elementId": "NW1ptYU6",
				"focus": 0.02955815573322196,
				"gap": 20.908174387452277
			},
			"endBinding": {
				"elementId": "y0f-g6rzCjLyrqln5rBfL",
				"focus": -0.09043105785811355,
				"gap": 26.397374861538992
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "DeFMrJEOonrqB-oTQLyab",
			"type": "arrow",
			"x": -129.29043858247474,
			"y": 392.2683563190617,
			"width": 1.7972321873719181,
			"height": 102.12343248042248,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 753436499,
			"version": 33,
			"versionNonce": 1323174035,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142927341,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					1.7972321873719181,
					102.12343248042248
				]
			],
			"lastCommittedPoint": [
				1.8236327228646587,
				103.94706520328714
			],
			"startBinding": {
				"elementId": "S7mjIs9e",
				"focus": 0.11718125717936684,
				"gap": 26.66873350225336
			},
			"endBinding": {
				"elementId": "NW1ptYU6",
				"focus": -0.1562857136332481,
				"gap": 28.167592162356186
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "cGUb_ZeaZOMyb4Cx2GNYO",
			"type": "arrow",
			"x": -151.19097330466616,
			"y": -25.34353721695129,
			"width": 1.8236327228646587,
			"height": 184.18690500933326,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 366313011,
			"version": 33,
			"versionNonce": 816429523,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142932500,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-1.8236327228646587,
					184.18690500933326
				]
			],
			"lastCommittedPoint": [
				-1.8236327228646587,
				184.18690500933326
			],
			"startBinding": {
				"elementId": "gCFSMRRC",
				"focus": 0.16208099574827942,
				"gap": 7.65646278304871
			},
			"endBinding": {
				"elementId": "S7mjIs9e",
				"focus": -0.18111389175949494,
				"gap": 6.756255024426366
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "_eqmu-RPHkKqa_5czon7f",
			"type": "arrow",
			"x": -756.34596724684,
			"y": 1536.0749244567933,
			"width": 564.2872097081249,
			"height": 1705.0624336586043,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1498801075,
			"version": 257,
			"versionNonce": 524338515,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1678142954785,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-277.5683031537262,
					-1305.4860851625808
				],
				[
					286.7189065543987,
					-1705.0624336586043
				]
			],
			"lastCommittedPoint": [
				286.7189065543987,
				-1705.0624336586043
			],
			"startBinding": {
				"elementId": "8Dt5JY00",
				"focus": -0.8289416701348075,
				"gap": 19.889351310642724
			},
			"endBinding": {
				"elementId": "gCFSMRRC",
				"focus": 0.8653998757092635,
				"gap": 23.87706069244132
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "text",
			"version": 403,
			"versionNonce": 376598611,
			"isDeleted": false,
			"id": "Kc72aT7m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 91.6960410783953,
			"y": 1557.8685701375487,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 719,
			"height": 125,
			"seed": 611830931,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "cpocOuzMTJcX23bK9TqQb",
					"type": "arrow"
				}
			],
			"updated": 1678142987942,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.",
			"rawText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears.",
			"baseline": 118,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "- The wolf let out a satisfied burp, and then poked through Granny's \n    wardrobe to find a nightgown that he liked.  \n\n- He added a frilly sleeping cap, and for good measure, dabbed some of \n    Granny's perfume behind his pointy ears."
		},
		{
			"type": "text",
			"version": 283,
			"versionNonce": 1703986195,
			"isDeleted": false,
			"id": "pm7j0DTi",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 213.5369943165582,
			"y": 1706.974139380233,
			"strokeColor": "#087f5b",
			"backgroundColor": "transparent",
			"width": 480,
			"height": 25,
			"seed": 897234835,
			"groupIds": [],
			"roundness": null,
			"boundElements": null,
			"updated": 1678143007706,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Se Resume el texto y se genera una diapositiva",
			"rawText": "Se Resume el texto y se genera una diapositiva",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Se Resume el texto y se genera una diapositiva"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 1649.5499882510824,
		"scrollY": 718.1190434837075,
		"zoom": {
			"value": 0.3778472324327366
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"previousGridSize": null
	},
	"files": {}
}
```
%%