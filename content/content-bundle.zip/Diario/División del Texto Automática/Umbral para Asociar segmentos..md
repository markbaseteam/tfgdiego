La idea inicial para asociar segmentes de palabras ya sean párrafos o frases es tomar todos los párrafos como "frases" de forma que dividimos cada una de sus partes los puntos que marcan los finales de la misma. Más adelante comaparamos las frases consecuentes mediante similitud según lo descrito en [[División del Texto Automática]]. Para considerar cómo de similares deben de ser las frases a utilizar se debe de considerar un umbral que puede ser tanto variable como fijo. 

En esta sección se muestran diferentes aproximaciones en cuanto al umbral que se va a a utilizar.


# Umbral Variante
## Media
Medir la media de la similitud con las siguientes frases para solo asociar aquellas frases qeue superen esa media, de forma que juntamos frases que sean relativamente "similares"

# Umbral Fijo
Utilizar un umbral fijo puede resultare ser bastante atractivo si consideramos que los valores de similitud se encuentran en el rango [-1, 1]. De esta forma podríamos pensar que una similitud *suficiente* como para que considerar que dos frases tienen la misma información de cara al resumen, después de probar diferentes valores que el sistema considera como iguales, se encuentran en el rango [0.2, 1], siendo este rango representativo del 60% de los valores posibles de similitud. **Indicando no obstante que aceptaríamos como frase similar al resumen toda aquella que tenga un mínimo del 20% de similitud semántica.** 