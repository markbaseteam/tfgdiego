# División del Texto Automática

para realizaar esta tarea, lo suyo es acudir de nuevo a nuestro amigo huggingface. Al parecer se puede medir la similitud en cuanto a significado de dos piezas de texto a través de modelos que normalizan las distintas frases. A través de este vector normalizado, simplemente haciendo la multiplicación interna de los vectores de dos frases tendríamos la similitud de ellas.

He usado una librería que era tremenda cagada así que vamos a probar esta.

# Sentence-similarity pip

```embed
title: 'sentence-similarity'
image: 'https://pypi.org/static/images/twitter.abaf4b19.webp'
description: 'Package to calculate the similarity score of two sentences'
url: 'https://pypi.org/project/sentence-similarity/'
```

Lo rompe?
![[Pasted image 20230304191055.png]]
Me parece muy terrible que lo esté rompiendo. Esta librería da conflictos con transformers porque usa otra versión no compatible.

# Sentence-Transformers/AllMini

```embed
title: 'sentence-transformers/all-MiniLM-L6-v2 · Hugging Face'
image: 'https://thumbnails.huggingface.co/social-thumbnails/models/sentence-transformers/all-MiniLM-L6-v2.png'
description: 'We’re on a journey to advance and democratize artificial intelligence through open source and open science.'
url: 'https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2'
```

Este es de huggingface y usa las cosas que ya tengo así que a ver si va algo mejor. Dice de usar la librería de arriba,  pero añade una opción DIY que es la que he usado. La idea es que te saca dos tensores con una serie de "embeddings" asociados a las frases de forma que se puede calcular la distancia entre las distintas frases. Esto se puede hacer mediante la similitud del coseno, o si el resultado está normalizado puede hacerse mediante una  multiplicación punto entre los dos vectores. Más información de esta weada aqui:

```embed
title: 'Computing Sentence Embeddings — Sentence-Transformers documentation'
image: 'https://www.sbert.net/_static/logo.png'
description: 'The basic function to compute sentence embeddings looks like this:'
url: 'https://www.sbert.net/examples/applications/computing-embeddings/README.html?highlight=cosine'
```



