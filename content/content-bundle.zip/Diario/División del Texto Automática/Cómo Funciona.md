# Cómo Funciona
Para explicar el funcionamiento de la división automática del texto es mejor usar un esquema ilustrativo.

![[Cómo Funciona 2023-03-06 23.33.32.excalidraw]]

# Step by Step:
![[Pasted image 20230306235116.png]]
![[Pasted image 20230306235124.png]]
![[Pasted image 20230306235140.png]]
![[Pasted image 20230306235201.png]]
![[Pasted image 20230306235215.png]]

# Optimizaciones
Para optimizar el proceso solo se comparan las palabras de un mismo párrafo a menos que sea la última de ese párrafo, que se compararía con el siguiente.