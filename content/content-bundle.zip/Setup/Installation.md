# 1. Instalar requisitos.

```shell
pip install kivy["base"]
pip install panflute==1.12.5
pip install pypandoc
pip install mdutils
pip install requests==2.28.1
pip install plyer
pip install pdfplumber
pip install imgurpython
pip install translate
```

# 2. Instalar transformers

```shell
conda install -c huggingface transformers
```

# 3. Installar API Google

```shell
pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
```

# 4. Image Generation

```shell
conda install pytorch==1.12.1 torchvision==0.13.1 -c pytorch
pip install transformers==4.19.2 diffusers invisible-watermark
pip install -e
```

# 5. Instalar Pandoc en tu dispositivo
Esto quizá no renta porque el usuario tiene que instalarse pandoc y quizá hay que darle otra vuelta.

```embed
title: 'Pandoc - Installing pandoc'
image: 'https://www.paypalobjects.com/en_US/i/scr/pixel.gif'
description: 'The simplest way to get the latest pandoc release is to use the installer.'
url: 'https://pandoc.org/installing.html'
```


# Install from environment.yml

```python
conda env update --file local.yml --prune
```
