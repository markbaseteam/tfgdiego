Empaquetar la app ha sido un trabajo duro porque se han tenido que meter uno a uno todos los paquetes que pyinstaller no detecta. No obstante, el empaquetamiento es sencillo dado el script .spec ya terminado.

```spec
# -*- mode: python ; coding: utf-8 -*-

from kivy_deps import sdl2, glew
block_cipher = None

SITE_PKGS_PATH = 'C:\\Users\\Usuario\\anaconda3\\envs\\tfg38-3\\Lib\\site-packages\\'

a = Analysis(
    ['..\\pythonProject\\index.py'],
    pathex=[],
    binaries=[],
    datas=[(SITE_PKGS_PATH + 'tqdm', 'tqdm\\'),
	(SITE_PKGS_PATH + 'tqdm-4.64.1.dist-info', 'tqdm-4.64.1.dist-info\\'),
	(SITE_PKGS_PATH +'regex','regex\\'),
	(SITE_PKGS_PATH +'regex-2022.7.9.dist-info','regex-2022.7.9.dist-info\\'),
	(SITE_PKGS_PATH +'requests','requests\\'),
	(SITE_PKGS_PATH +'requests_oauthlib','requests_oauthlib\\'),
	(SITE_PKGS_PATH +'requests_oauthlib-1.3.1.dist-info','requests_oauthlib-1.3.1.dist-info\\'),
	(SITE_PKGS_PATH +'requests-2.28.1.dist-info','requests-2.28.1.dist-info\\'),
	(SITE_PKGS_PATH +'packaging','packaging\\'),
	(SITE_PKGS_PATH +'packaging-22.0.dist-info','packaging-22.0.dist-info\\'),
	(SITE_PKGS_PATH +'filelock','filelock\\'),
	(SITE_PKGS_PATH +'filelock-3.9.0.dist-info','filelock-3.9.0.dist-info\\'),
	(SITE_PKGS_PATH + 'numpy', 'numpy\\'),
	(SITE_PKGS_PATH + 'numpy-1.23.5.dist-info', 'numpy-1.23.5.dist-info\\'),
	(SITE_PKGS_PATH + 'tokenizers', 'tokenizers\\'),
	(SITE_PKGS_PATH + 'tokenizers-0.13.0.dev0-py3.8-win-amd64.egg-info', 'tokenizers-0.13.0.dev0-py3.8-win-amd64.egg-info\\'),
	(SITE_PKGS_PATH + 'plyer', 'plyer\\'),
	(SITE_PKGS_PATH + 'plyer-2.1.0.dist-info', 'plyer-2.1.0.dist-info\\'),
	(SITE_PKGS_PATH + 'torch', 'torch\\'),
	(SITE_PKGS_PATH + 'torch-1.13.1.dist-info', 'torch-1.13.1.dist-info\\'),
	(SITE_PKGS_PATH + 'torchgen', 'torchgen\\'),
	(SITE_PKGS_PATH + 'google', 'google\\'),
	(SITE_PKGS_PATH + 'google_auth_httplib2-0.1.0.dist-info', 'google_auth_httplib2-0.1.0.dist-info\\'),
	(SITE_PKGS_PATH + 'google_auth_oauthlib', 'google_auth_oauthlib\\'),
	(SITE_PKGS_PATH + 'google_auth_oauthlib-1.0.0.dist-info', 'google_auth_oauthlib-1.0.0.dist-info\\'),
	(SITE_PKGS_PATH + 'google_auth-2.16.0.dist-info', 'google_auth-2.16.0.dist-info\\'),
	(SITE_PKGS_PATH + 'googleapiclient', 'googleapiclient\\'),
	(SITE_PKGS_PATH + 'googleapis_common_protos-1.58.0.dist-info', 'googleapis_common_protos-1.58.0.dist-info\\')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='resbailing-v0.1',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe, Tree('..\\pythonProject\\'),
    a.binaries,
    a.zipfiles,
    a.datas,
	*[Tree(p) for p in (sdl2.dep_bins + glew.dep_bins)],
    strip=False,
    upx=True,
    upx_exclude=[],
    name='resbailing-v0.1',
)

```

Dicho esto, y abriendo una ventana de comandos en el lugar donde se quiere realizar el empaquetado, debe de ejecutarse el siguiente comando:

```shell
> python -m PyInstaller .\resbailing-v0.1.spec
```

Siendo resbailing-v0.1.spec el nombre del archivo script para generar la app.