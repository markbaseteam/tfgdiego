# Contenidos.

%% Begin Waypoint %%
- [[02_Tablero]]
- **ADR**
	- [[AD01]]
	- [[AD03 - Entorno de Desarrollo]]
	- [[AD04 - UI]]
	- [[AD05 - Apariencia de la Aplicación]]
	- [[AD06 - Almacenar información del documento a procesar.]]
	- [[AD07 - Procesar Información de Fichero Markdown]]
	- [[AD08 - Imágenes online]]
	- **Templates**
		- [[ADXX]]
- **assets**

- **CANVAS**

- **Diario**
	- **01_Planificación**
		- [[Adaptaciones de SCRUM]]
	- **[[02_Prototipo 1]]**
	- **[[98_Mejoras]]**
		- [[98_Mejoras]]
	- **99_Errores**
		- [[ERR-01 ntpath has no attribute sep]]
		- [[ERR-02 No se puede borrar diapositiva]]
		- [[ERR-03 Imágenes Panflute]]
		- [[ERR-04 Requests Library not Installed]]
	- **[[División del Texto Automática]]**
		- **assets**
			- [[Cómo Funciona 2023-03-06 23.33.32.excalidraw]]
		- [[Cómo Funciona]]
		- [[División del Texto Automática]]
		- [[Umbral para Asociar segmentos.]]
	- **Generación de Imágenes**
		- [[Qué Usamos para generar imágenes.]]
	- **[[Markdowns de Ejemplo]]**
		- [[Caperucita Roja (Inglés)]]
		- [[Caperucita Roja]]
		- [[Gilgamesh (English)]]
		- [[Markdown de ejemplo Formateada.]]
		- [[Markdown Ejemplo 2]]
		- [[Markdowns de Ejemplo]]
	- **References**
		- **[[CodePatterns]]**
			- [[CodePatterns]]
- **Setup**
	- [[Empaquetar la Aplicación]]
	- [[Installation]]
- [[TFG]]

%% End Waypoint %%

# Kanban

[[02_Tablero]]

# TODO

```tasks
path includes TFG
not done
```

# Done

```tasks
path includes TFG
done
sort by done
```



# Trabajo por hacer
- [x] Añadir sección hablando sobre la API de google. ✅ 2022-12-31
- [x] Mandar el paper sobre el modelo categorizado ✅ 2022-11-24