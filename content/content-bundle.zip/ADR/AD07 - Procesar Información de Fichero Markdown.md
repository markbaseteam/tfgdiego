# TITULO

## Problema
Es necesario encontrar una forma útil de tratar con toda la información que se encuentra en un fichero markdown.

## Decisión

```python
import io
import panflute  
import pypandoc

data = pypandoc.convert_file(self.path, 'json')  
doc = panflute.load(io.StringIO(data))
```

Usar pypandoc para convertir el archivo en markdown a json y luego generar un documento de panflute, que es un documento que organiza cada una de las palabras según el "estilo" que se le haya puesto en el archivo para poder tratar con los contenidos.

A partir de este documento panflute se pueden extraer por propiedades los textos que así se deseen.

| --        | --    |
| --------- | ----- |
| __Estado__          |  Aprobada     |
| __Grupo__ | Desarrollo |

### Suposiciones
- Es necesario analizar cada uno de los elementos del markdown para procesarlos.
- El archivo en markdown tiene el formato correcto.

### Restricciones
_Intencionalmente en blanco_

## Alternativas
### Leer el Archivo como texto en plano.
Iterando sobre el documento en markdown puede sacarse adicionalmente cada uno de los componentes del texto. No obstante, esto sería implementar una labor de clasificación muy parecida a la que hace panflute con los archivos json, por lo que no tiene sentido implementar algo que ya existe.

## Motivo de la Decisión
No reinventar la rueda, y aprovechar librerías ya creadas para realizar el procesamiento.

## Impacto de la Decisión
A decision comes with many implications, as the REMAP metamodel denotes. For example, a decision might introduce a need to make other decisions, create new requirements, or modify existing requirements; pose additional constraints to the environment; require renegotiating scope or schedule with customers; or require additional staff training. Clearly understanding and stating your decision’s implications can be very effective in gaining buy-in and creating a roadmap for architecture execution.

## Decisiones Relacionadas
It’s obvious that many decisions are related; you can list them here. However, we’ve found that in practice, a traceability matrix, decision trees, or metamodels are more useful. Metamodels are useful for showing complex relationships diagrammatically (such as Rose models).

## Requisitos Relacionados
Decisions should be business driven. To show accountability, explicitly map your decisions to the objectives or requirements. You can enumerate these related requirements here, but we’ve found it more convenient to reference a traceability matrix. You can assess each architecture decision’s contribution to meeting each requirement, and then assess how well the requirement is met across all decisions. If a decision doesn’t contribute to meeting a requirement, don’t make that decision.

## Artefactos Relacionados
List the related architecture, design, or scope documents that this decision impacts.

## Principios Relacionados
 If the enterprise has an agreed-upon set of principles, make sure the decision is consistent with one or more of them. This helps ensure alignment along domains or systems.

## Notas
Because the decision-making process can take weeks, we’ve found it useful to capture notes and issues that the team discusses during the socialization process.