# TITULO

## Problema
La API de Google Slides obliga a que las imágenes deban primero ser subidas a un servicio online para que slides pueda acceder a ellas, no permite como tal subir directamente imágenes locales.

## Decisión
Implementar la API de Imgur para subir las imágenes y usar los enlaces de esas imágenes para colocarlas en las slides de Google.

| --        | --    |
| --------- | ----- |
| __Estado__          |  Implementada     |
| __Grupo__ | Generación de Imágenes |

### Suposiciones
- Es necesario que las imágenes sean accesibles desde internet antes de incorporarlas a una diapositiva.

### Restricciones
- No se puede usar (aún) un servidor del que abrir algún puerto donde montar un sistema de archivos al que se pueda acceder desde internet.
- No se pueden subir imágenes desde local.
- Las imágenes temporales de Google Drive requieren de subscripción.


## Alternativas
### Abrir algún puerto a internet del sistema local.
En primer lugar, exponer los sistemas de nuestros clientes para que puedan subir unas imágenes a Google Slides no es para nada óptimo ya que crea vulnerabilidades que pueden no ser buenas para ellos.

Además, la configuración previa que se necesita anteriormente para abrir los puertos y hacer disponibles las imágenes no puede esperarse de ellos tampoco.

### Tener un servidor donde subir las imágenes.
Esta opción sería incluso **mejor** que la decisión tomada, pero como de momento no tengo acceso a ningún servidor donde poder tener las imágenes disponibles desde internet


## Motivo de la Decisión
Outline why you selected a position, including items such as implementation cost, total ownership cost, time to market, and required development resources’ availability. This is probably as important as the decision itself

## Impacto de la Decisión
A decision comes with many implications, as the REMAP metamodel denotes. For example, a decision might introduce a need to make other decisions, create new requirements, or modify existing requirements; pose additional constraints to the environment; require renegotiating scope or schedule with customers; or require additional staff training. Clearly understanding and stating your decision’s implications can be very effective in gaining buy-in and creating a roadmap for architecture execution.

## Decisiones Relacionadas
It’s obvious that many decisions are related; you can list them here. However, we’ve found that in practice, a traceability matrix, decision trees, or metamodels are more useful. Metamodels are useful for showing complex relationships diagrammatically (such as Rose models).

## Requisitos Relacionados
Decisions should be business driven. To show accountability, explicitly map your decisions to the objectives or requirements. You can enumerate these related requirements here, but we’ve found it more convenient to reference a traceability matrix. You can assess each architecture decision’s contribution to meeting each requirement, and then assess how well the requirement is met across all decisions. If a decision doesn’t contribute to meeting a requirement, don’t make that decision.

## Artefactos Relacionados
List the related architecture, design, or scope documents that this decision impacts.

## Principios Relacionados
 If the enterprise has an agreed-upon set of principles, make sure the decision is consistent with one or more of them. This helps ensure alignment along domains or systems.

## Notas
Because the decision-making process can take weeks, we’ve found it useful to capture notes and issues that the team discusses during the socialization process.